import { NavLink } from "react-router-dom";

function Navbar(){
  return (
    <div className="border-b-2 border-gray-500">
      <NavLink
        className={(state) => {
          return state.isActive ? "text-blue-400" : "text-black" + " px-2 py-1";
        }}
        to="/admin"
      >Admin</NavLink>
      <NavLink
        className={(state) => {
          return state.isActive ? "text-blue-400" : "text-black" + " px-2 py-1";
        }}
        to="/doctor"
      >Dokter</NavLink>
      <NavLink
        className={(state) => {
          return state.isActive ? "text-blue-400" : "text-black" + " px-2 py-1";
        }}
        to="/login"
      >Login</NavLink>
      <NavLink
        className={(state) => {
          return state.isActive ? "text-blue-400" : "text-black" + " px-2 py-1";
        }}
        to="/pasien"
      >Pasien</NavLink>
      <NavLink
        className={(state) => {
          return state.isActive ? "text-blue-400" : "text-black" + " px-2 py-1";
        }}
        to="/register"
      >Register</NavLink>
    </div>
  );
};

export default Navbar;
