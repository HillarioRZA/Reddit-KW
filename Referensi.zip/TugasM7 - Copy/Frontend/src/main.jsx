import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App.jsx';
import { createBrowserRouter, RouterProvider, Navigate} from 'react-router-dom';
import AdminMenu from './pages/adminMenu.jsx';
import Admin from './pages/admin.jsx';
import AdminMedicine from './pages/adminMedicine.jsx';
import AdminEdit from './pages/adminEdit.jsx';
import Dokter from './pages/dokter.jsx';
import DokterMenu from './pages/dokterMenu.jsx';
import DokterConsult from './pages/dokterConsult.jsx';
import Login from './pages/login.jsx';
import PasienMenu from './pages/pasienMenu.jsx';
import Pasien from './pages/pasien.jsx';
import PasienAppointment from './pages/pasienAppointment.jsx';
import Register from './pages/register.jsx';
import dataHandler from './assets/dataHandler.jsx';

const { loadUserList, loadDoctorList, registerUser, loginUser, addAppointment, 
        loadAppointmentDokter, loadAppointmentPasien, pickAppointment, loadSelectedAppointment, 
        giveConsult, loadMedicine, addMedicine, editMedicine } = dataHandler

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        index: true,
        element: <Navigate to="/login" replace />,
      },
      {
        path: "/admin",
        element: <AdminMenu />,
        children:[
          {
            index: true,
            element: <Admin/>,
            loader: loadUserList,
          },
          {
            path: "medicine",
            element: <AdminMedicine/>,
            loader: loadMedicine,
            action: addMedicine
          },
          {
            path: "edit",
            element: <AdminEdit/>,
            action: editMedicine
          }
        ]
      },
      {
        path: "/doctor",
        element: <DokterMenu />,
        action: pickAppointment,
        children:[
          {
            index: true,
            element: <Dokter />,
            loader: loadAppointmentDokter,
          },
          {
            path: "consult",
            element: <DokterConsult />,
            loader: loadSelectedAppointment,
            action: giveConsult
          },
        ]
      },
      {
        path: "/login",
        element: <Login />,
        action: loginUser
      },
      {
        path: "/patient", 
        element: <PasienMenu />,
        action: addAppointment, 
        children: [
          {
            index: true,
            element: <Pasien />,
            loader: loadDoctorList,
          },
          {
            path: "list",
            element: <PasienAppointment />,
            loader: loadAppointmentPasien
          },
        ],
      },
      {
        path: "/register",
        element: <Register />,
        action: registerUser,
      },
    ],
  },
]);



createRoot(document.getElementById('root')).render(
  <StrictMode>
      <RouterProvider router={router} />
  </StrictMode>
);
